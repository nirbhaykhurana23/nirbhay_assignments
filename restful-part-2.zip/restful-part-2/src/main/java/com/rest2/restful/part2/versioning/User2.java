package com.rest2.restful.part2.versioning;

public class User2 {
    private Name name;

    User2(){}

    public User2(Name name) {
        this.name = name;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }
}
