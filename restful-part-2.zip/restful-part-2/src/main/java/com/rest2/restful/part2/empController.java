package com.rest2.restful.part2;
    
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.*;
import java.util.List;


//for hateoas
/*
import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
*/

@RestController
public class empController {

    @Autowired
    private empDaoService service;

    @Autowired
    private MessageSource messageSource;

    @GetMapping("/emp")
    public List<employee> retrieveAllEmployees(){
        return service.findAll();
    }

    @GetMapping("/emp/{id}")
    public employee retrieveEmployee(@PathVariable int id){
        employee emp1 = service.findOne(id);
        return emp1;
    }

    @PostMapping(path="/emp")
    public void createEmp(@RequestBody employee emp1){
        employee savedEmp=service.save(emp1);
    }

    @DeleteMapping("/emp/{id}")
    public void deleteEmployee(@PathVariable int id){
        employee emp1=service.deleteById(id);
    }

    @GetMapping("/emp-internationalized/{name}")
    public String helloInternationalized(@PathVariable String name){
        return messageSource.getMessage("hello.message",new Object[]{name},LocaleContextHolder.getLocale());
    }

/*
    //HATEOAS
    @GetMapping("/emp-hateoas/{id}")
    public EntityModel<employee> retrieveEmployeeHateoas(@PathVariable int id){
        employee emp1 = service.findOne(id);

        EntityModel<employee> resource = new EntityModel<>(emp1);
        WebMvcLinkBuilder linkTo = linkTo(methodOn(this.getClass()).retrieveAllEmployees());
        resource.add(linkTo.withRel("all-employees"));
        return resource;
    }
*/


}
