package com.spring.employee.jpa.with.hibernate1;

import com.spring.employee.jpa.with.hibernate1.entities.Employee;
import com.spring.employee.jpa.with.hibernate1.repos.EmployeeRepository;
import com.spring.employee.jpa.with.hibernate1.repos.EmployeeRepository2;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import java.util.List;

@SpringBootTest
class JpaWithHibernate1ApplicationTests {

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	EmployeeRepository2 employeeRepository2;

	@Test
	void contextLoads() {
	}

	@Test
	public void testCreate(){
		Employee employee=new Employee();
		employee.setName("Nirbhay");
		employee.setAge(25);
		employee.setId(1);
		employee.setLocation("Delhi");

		employeeRepository.save(employee);

		Employee employee2=new Employee();
		employee2.setName("Aman");
		employee2.setAge(29);
		employee2.setId(2);
		employee2.setLocation("Goa");

		employeeRepository.save(employee2);

		Employee employee3=new Employee();
		employee3.setName("Adam");
		employee3.setAge(18);
		employee3.setId(3);
		employee3.setLocation("Hyderabad");

		employeeRepository.save(employee3);

		Employee employee4=new Employee();
		employee4.setName("John");
		employee4.setAge(22);
		employee4.setId(4);
		employee4.setLocation("Mumbai");

		employeeRepository.save(employee4);
	}

	@Test
	public void testUpdate(){
		Employee employee=employeeRepository.findById(1).get();
		employee.setLocation("Bangalore");
		employeeRepository.save(employee);
	}

	@Test
	public void testDelete(){
		employeeRepository.deleteById(1);
	}

	@Test
	public void testRead(){
		Employee employee=employeeRepository.findById(1).get();
		System.out.println("Name is = " + employee.getName());
		System.out.println("Id is = " + employee.getId());
	}

	@Test
	public void testCount(){
		System.out.println("Total employees are = " + employeeRepository.count());
	}

	@Test
	public void testFindAllPagingAndSorting(){
		employeeRepository2.findAll(PageRequest.of(1,2, Sort.by("age"))).forEach(p-> System.out.println(p.getName()));
	}

	@Test
	public void testFindByName(){
		List<Employee> employees = employeeRepository.findByName("Nirbhay");
		employees.forEach(e-> System.out.println(e.getId()));
		employees.forEach(e-> System.out.println(e.getLocation()));
	}

	@Test
	public void testFindByNameLike(){
		List<Employee> employees = employeeRepository.findByNameLike("A%");
		employees.forEach(e-> System.out.println(e.getName()));
	}

	@Test
	public void testFindByAgeBetween(){
		List<Employee> employees = employeeRepository.findByAgeBetween(28,32);
		employees.forEach(e-> System.out.println(e.getName()));
	}

}
