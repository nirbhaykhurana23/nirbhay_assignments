package com.spring.employee.jpa.with.hibernate1.repos;

import com.spring.employee.jpa.with.hibernate1.entities.Employee;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface EmployeeRepository2 extends PagingAndSortingRepository<Employee, Integer> {
}
