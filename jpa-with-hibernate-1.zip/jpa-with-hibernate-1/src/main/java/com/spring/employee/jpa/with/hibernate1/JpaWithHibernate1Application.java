package com.spring.employee.jpa.with.hibernate1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaWithHibernate1Application {

	public static void main(String[] args) {
		SpringApplication.run(JpaWithHibernate1Application.class, args);
	}

}
