package com.SpringFramework.spring.framework.LooseCoupling;

public interface Calculate {
    public int cal(int a,int b);
}
