package com.SpringFramework.spring.framework.Employee;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class ExcellentWorker implements Worker{

    @Override
    public void show() {
        System.out.println("Hello excellent worker");
    }
}
