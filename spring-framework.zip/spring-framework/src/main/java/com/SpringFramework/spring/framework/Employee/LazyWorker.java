package com.SpringFramework.spring.framework.Employee;

import org.springframework.stereotype.Component;

@Component
public class LazyWorker implements Worker {

    @Override
    public void show() {
        System.out.println("Hello lazy worker");
    }
}
