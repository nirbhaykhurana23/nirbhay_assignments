package com.SpringFramework.spring.framework.TightCoupling;

public class Sum {
    private int c=0;
    public int calculate_sum(int a,int b) {
        c=a+b;
        return c;
    }
}
