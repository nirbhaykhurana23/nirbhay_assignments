package com.SpringFramework.spring.framework.LooseCoupling;

public class Subtract implements Calculate {
    @Override
    public int cal(int a, int b) {
        int c=0;
        c=a-b;
        return c;
    }
}
