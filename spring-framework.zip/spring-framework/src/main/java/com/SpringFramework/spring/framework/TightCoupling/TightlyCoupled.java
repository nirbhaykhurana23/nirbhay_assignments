package com.SpringFramework.spring.framework.TightCoupling;

public class TightlyCoupled {

    Sum sum=new Sum();

    public void call_sum(){
        int res=sum.calculate_sum(2,3);
        System.out.println(res);
    }

}
