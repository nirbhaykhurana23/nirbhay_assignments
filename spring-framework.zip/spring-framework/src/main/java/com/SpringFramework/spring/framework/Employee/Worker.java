package com.SpringFramework.spring.framework.Employee;

public interface Worker {
    public void show();
}
