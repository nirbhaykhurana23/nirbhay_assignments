package com.SpringFramework.spring.framework;

import com.SpringFramework.spring.framework.Employee.LazyWorker;
import com.SpringFramework.spring.framework.Employee.Manager;
import com.SpringFramework.spring.framework.LooseCoupling.Calculate;
import com.SpringFramework.spring.framework.LooseCoupling.Subtract;
import com.SpringFramework.spring.framework.TightCoupling.TightlyCoupled;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringFrameworkApplication {

	public static void main(String[] args) {

		ApplicationContext applicationContext=SpringApplication.run(SpringFrameworkApplication.class, args);
		Manager manager=applicationContext.getBean(Manager.class);
		manager.call_show();

		for (String i:applicationContext.getBeanDefinitionNames()){
			System.out.println(i);
		}


		//For tight coupling
		TightlyCoupled tightlyCoupled=new TightlyCoupled();
		tightlyCoupled.call_sum();

		//For loose coupling
		Calculate calculate=new Subtract();
		System.out.println(calculate.cal(10, 6));


	}

}
