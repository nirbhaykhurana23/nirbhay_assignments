package com.SpringFramework.spring.framework.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Manager {

    @Autowired
    private Worker worker;

    public Manager(Worker worker){
        super();
        this.worker=worker;
    }

    public void call_show(){
        worker.show();
    }
}
