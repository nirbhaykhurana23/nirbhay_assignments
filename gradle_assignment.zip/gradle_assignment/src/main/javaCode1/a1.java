public class a1 {
    public static void main(String[] args) {
        System.out.println("hello a1");
    }
}
