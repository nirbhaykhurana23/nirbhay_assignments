package healthycoderapp;

public enum Gender {
	MALE, FEMALE
}
