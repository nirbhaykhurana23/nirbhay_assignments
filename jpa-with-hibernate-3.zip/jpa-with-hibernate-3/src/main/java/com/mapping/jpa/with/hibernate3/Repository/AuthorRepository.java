package com.mapping.jpa.with.hibernate3.Repository;

import com.mapping.jpa.with.hibernate3.entities.Author;
import org.springframework.data.repository.CrudRepository;

public interface AuthorRepository extends CrudRepository<Author, Integer> {
}
