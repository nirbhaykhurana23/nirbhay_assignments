package com.mapping.jpa.with.hibernate3.entities;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
public class Author {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name = "author_id")
    private List<Subject> subjects;

    // #######  one to many  #####

    /*@OneToMany(mappedBy = "author", cascade=CascadeType.ALL)
    private Set<Book> books;*/


    // #######  many to many  #####
    /*@ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
    joinColumns = @JoinColumn(referencedColumnName = "id"),
    inverseJoinColumns = @JoinColumn(referencedColumnName = "book_id"))
    private Set<Book> books;*/


    // #######  one to one  #####
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn
    private Book book;

    @Embedded
    private Address address;

    public Author(){    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }

    public void addSubjects(Subject subject){
        if (subject!=null){
            if (subjects==null){
                subjects=new ArrayList<>();
            }
            subjects.add(subject);
        }
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    /*public Set<Book> getBooks() {
        return books;
    }

    public void setBooks(Set<Book> books) {
        this.books = books;
    }

    public void addBooks(Book book){
        if (book!=null){
            if (books==null){
                books=new HashSet<>();
            }
            books.add(book);
        }
    }*/

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }
}
