package com.mapping.jpa.with.hibernate3.entities;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int book_id;

    private String book_name;

    // #######  one to many  #####
    /*@ManyToOne
    @JoinColumn(name = "author_id")
    private Author author;*/


    // #######  many to many  #####
   /* @ManyToMany(mappedBy = "books")
    private Set<Author> authors;*/

   
    // #######  one to one  #####
    @OneToOne(mappedBy = "book")
    private Author author;

    public Book(){   }

    public String getBook_name() {
        return book_name;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    /*public Set<Author> getAuthors() {
        return authors;
    }

    public void setAuthors(Set<Author> authors) {
        this.authors = authors;
    }*/
}
