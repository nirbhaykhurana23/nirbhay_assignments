package com.mapping.jpa.with.hibernate3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaWithHibernate3Application {

	public static void main(String[] args) {
		SpringApplication.run(JpaWithHibernate3Application.class, args);
	}

}
