package com.mapping.jpa.with.hibernate3;

import com.mapping.jpa.with.hibernate3.Repository.AuthorRepository;
import com.mapping.jpa.with.hibernate3.entities.Address;
import com.mapping.jpa.with.hibernate3.entities.Author;
import com.mapping.jpa.with.hibernate3.entities.Book;
import com.mapping.jpa.with.hibernate3.entities.Subject;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@SpringBootTest
class JpaWithHibernate3ApplicationTests {

	@Autowired
	AuthorRepository authorRepository;

	@Test
	void contextLoads() {
	}

	@Test
	public void testCreate(){

		Author author=new Author();

		Subject subject1=new Subject();
		subject1.setSubject("english");
		Subject subject2=new Subject();
		subject2.setSubject("hindi");
		Subject subject3=new Subject();
		subject3.setSubject("maths");

		author.addSubjects(subject1);
		author.addSubjects(subject2);
		author.addSubjects(subject3);

		Address address=new Address();
		address.setStreet_number(101);
		address.setLocation("Janakpuri");
		address.setState("Delhi");

		author.setAddress(address);

		// #######  one to many  #####
		/*Book book=new Book();
		book.setBook_name("Success");

		author.addBooks(book);
		book.setAuthor(author);*/

		//########  many to many #####
		/*HashSet<Book> books=new HashSet<>();
		Book book=new Book();
		book.setBook_name("Success");
		books.add(book);
		author.setBooks(books);*/

		//#######  one to one #######
		Book book=new Book();
		book.setBook_name("Success");
		book.setAuthor(author);
		author.setBook(book);

		authorRepository.save(author);


	}

}

