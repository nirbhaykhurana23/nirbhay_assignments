package com.hibernate2.jpa.with.hibernate2;

import com.hibernate2.jpa.with.hibernate2.Repository.EmployeeRepository;
import com.hibernate2.jpa.with.hibernate2.Repository.PaymentRepository;
import com.hibernate2.jpa.with.hibernate2.Repository.PersonRepository;
import com.hibernate2.jpa.with.hibernate2.entities.Employee;
import com.hibernate2.jpa.with.hibernate2.entities.Person;
import com.hibernate2.jpa.with.hibernate2.entities.TotalSalary;
import com.hibernate2.jpa.with.hibernate2.entities.inheritance.Check;
import com.hibernate2.jpa.with.hibernate2.entities.inheritance.CreditCard;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@SpringBootTest
class JpaWithHibernate2ApplicationTests {

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	PersonRepository personRepository;

	@Autowired
	PaymentRepository paymentRepository;

	@Test
	void contextLoads() {
	}

	@Test
	public void testCreate(){
		Employee employee1=new Employee();
		employee1.setFirstName("Nirbhay");
		employee1.setLastName("Khurana");
		employee1.setSalary(40000);
		employee1.setAge(25);
		employeeRepository.save(employee1);

		Employee employee2=new Employee();
		employee2.setFirstName("Ram");
		employee2.setLastName("Kumar");
		employee2.setSalary(50000);
		employee2.setAge(28);
		employeeRepository.save(employee2);

		Employee employee3=new Employee();
		employee3.setFirstName("Shubham");
		employee3.setLastName("Singh");
		employee3.setSalary(42000);
		employee3.setAge(48);
		employeeRepository.save(employee3);

		Employee employee4=new Employee();
		employee4.setFirstName("Sid");
		employee4.setLastName("Bhatia");
		employee4.setSalary(70000);
		employee4.setAge(22);
		employeeRepository.save(employee4);
	}

	@Test
	public void testFindEmpBySalary(){
		List<Object[]> result=employeeRepository.findEmpBySalary();
		for (Object[] objects : result){
			System.out.println(objects[0]);
			System.out.println(objects[1]);
		}
	}

	@Transactional
	@Rollback(false)
	@Test
	void testUpdateEmployeeSalary(){
		employeeRepository.updateEmployeeSalary(60500,employeeRepository.avgSalary());
	}

	@Transactional
	@Rollback(false)
	@Test
	public void testDeleteEmployeeWithMinSal(){
		employeeRepository.deleteEmployeeWithMinSal(employeeRepository.minSalary());
	}

	@Test
	public void testFindByEmpLastName(){
		List<Object[]> result=employeeRepository.findByEmplastname();
		for (Object[] objects : result){
			System.out.println(objects[0]);
			System.out.println(objects[1]);
			System.out.println(objects[2]);
		}
	}

	@Transactional
	@Rollback(false)
	@Test
	public void testDelByEmpAge(){
		employeeRepository.delByEmpAge(45);
	}

	//Inheritance

	@Test
	public void testPaymentCreate() {
		Check check1 = new Check();
		check1.setId(1);
		check1.setAmount(1000.00);
		check1.setChecknumber("01156754893");

		CreditCard creditCard = new CreditCard();
		creditCard.setId(2);
		creditCard.setAmount(1600.90);
		creditCard.setCardnumber("535498768973");

		paymentRepository.save(check1);
		paymentRepository.save(creditCard);
	}

	//Component Mapping

	@Test
	public void testEmployeeCreate() {
		Person person1 = new Person();
		person1.setFirstname("Nibhay");
		person1.setLastname("Khurana");
		person1.setAge(23);
		person1.setTaxamount(100d);

		TotalSalary totalSalary1 = new TotalSalary();
		totalSalary1.setBasicsalary(2500d);
		totalSalary1.setBonussalary(100d);
		totalSalary1.setSpecialallowance(500d);

		person1.setTotalSalary(totalSalary1);
		personRepository.save(person1);
	}


}
