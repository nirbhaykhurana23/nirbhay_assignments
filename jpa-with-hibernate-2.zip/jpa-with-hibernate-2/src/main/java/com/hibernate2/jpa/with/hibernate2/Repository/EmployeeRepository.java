package com.hibernate2.jpa.with.hibernate2.Repository;

import com.hibernate2.jpa.with.hibernate2.entities.Employee;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

    //jpql

    @Query("select firstName, lastName from Employee where salary>(select avg(salary) from Employee) order by age asc, salary desc")
    List<Object[]> findEmpBySalary();

    @Query("select avg(salary) from Employee")
    public int avgSalary();

    @Modifying
    @Query("update Employee set salary=:varSal where salary <:avgSal ")
    public void updateEmployeeSalary(@Param("varSal") int varSal,@Param("avgSal") int avgSal);

    @Query("select MIN(salary) from Employee")
    public int minSalary();

    @Modifying
    @Query("delete from Employee where salary=:minSal")
    public void deleteEmployeeWithMinSal(@Param("minSal") int minSal);


    //native sql

    @Query(value = "select empid, empfirstname, empage from employee_table where emplastname LIKE '%Singh'", nativeQuery = true)
    List<Object[]> findByEmplastname();

    @Modifying
    @Query(value = "delete from employee_table where empage>:age", nativeQuery = true)
    void delByEmpAge(@Param("age") int age);


}
