package com.hibernate2.jpa.with.hibernate2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaWithHibernate2Application {

	public static void main(String[] args) {
		SpringApplication.run(JpaWithHibernate2Application.class, args);
	}

}
