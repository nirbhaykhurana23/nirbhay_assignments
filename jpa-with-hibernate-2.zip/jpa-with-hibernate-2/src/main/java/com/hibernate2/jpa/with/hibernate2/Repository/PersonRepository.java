package com.hibernate2.jpa.with.hibernate2.Repository;

import com.hibernate2.jpa.with.hibernate2.entities.Person;
import org.springframework.data.repository.CrudRepository;

public interface PersonRepository extends CrudRepository<Person, Integer> {

}
