package com.hibernate2.jpa.with.hibernate2.Repository;

import com.hibernate2.jpa.with.hibernate2.entities.inheritance.Payment;
import org.springframework.data.repository.CrudRepository;

public interface PaymentRepository extends CrudRepository<Payment, Integer> {

}
