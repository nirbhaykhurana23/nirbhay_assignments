package com.example.demo2;

import javax.validation.constraints.*;

public class employee {

    @NotNull
    @Size(min = 3, max = 60, message = "Name should have atleast 3 Characters and upto 60 Characters long")
    private String name;

    @NotNull
    @Min(value = 20, message = "Minimum Age of Employee should be 20")
    private Integer age;

    private Integer id;

    public employee(Integer id, Integer age, String name) {
        this.id = id;
        this.age = age;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "employee{" +
                "id=" + id +
                ", age=" + age +
                ", name='" + name + '\'' +
                '}';
    }
}
