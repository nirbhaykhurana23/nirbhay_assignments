package com.example.demo2;
    
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class empController {

    @Autowired
    private empDaoService service;

    @GetMapping("/emp")
    public List<employee> retrieveAllEmployees(){
        return service.findAll();
    }

    @GetMapping("/emp/{id}")
    public employee retrieveEmployee(@PathVariable int id){
        employee emp1 = service.findOne(id);
        if (emp1==null)
            throw new UserNotFoundException("id-"+id);
        return emp1;
    }

    @DeleteMapping("/emp/{id}")
    public void deleteUser(@PathVariable int id){
        employee emp1=service.deleteById(id);

        if (emp1==null)
            throw new UserNotFoundException("id-"+id);

    }

    @PostMapping(path="/emp")
    public void createEmp(@Valid @RequestBody employee emp1){
        employee savedEmp=service.save(emp1);
    }

    @PutMapping(path="/emp/{id}")
    public void updateEmp(@RequestBody employee emp1, @PathVariable int id){
        employee currentEmp = service.findOne(id);
        if (currentEmp==null)
            throw new UserNotFoundException("id-"+id);

        currentEmp.setAge(emp1.getAge());
        currentEmp.setName(emp1.getName());

    }


}
